def simple_print(x):
    print("Result: ", x)
    
def pro_print(x):
    print("The result of the operation is ", x)